import { 
  users, crops, requests, transactions, conversations, messages,
  type User, type InsertUser,
  type Crop, type InsertCrop,
  type Request, type InsertRequest,
  type Transaction, type InsertTransaction,
  type Conversation, type InsertConversation,
  type Message, type InsertMessage
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Crops
  getAllCrops(): Promise<Crop[]>;
  getCrop(id: number): Promise<Crop | undefined>;
  createCrop(crop: InsertCrop): Promise<Crop>;
  updateCrop(id: number, updates: Partial<Crop>): Promise<Crop | undefined>;

  // Requests
  getAllRequests(): Promise<Request[]>;
  getRequestsByBuyer(buyerId: number): Promise<Request[]>;
  createRequest(request: InsertRequest & { buyerId: number }): Promise<Request>;

  // Transactions
  getAllTransactions(): Promise<Transaction[]>;
  getTransactionsByUser(userId: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;

  // Conversations
  getConversationsByUser(userId: number): Promise<Conversation[]>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;

  // Messages
  getMessagesByConversation(conversationId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private crops: Map<number, Crop>;
  private requests: Map<number, Request>;
  private transactions: Map<number, Transaction>;
  private conversations: Map<number, Conversation>;
  private messages: Map<number, Message>;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.crops = new Map();
    this.requests = new Map();
    this.transactions = new Map();
    this.conversations = new Map();
    this.messages = new Map();
    this.currentId = 1;

    // Initialize with sample data
    this.initializeData();
  }

  private initializeData() {
    // Create sample user
    const user: User = {
      id: 1,
      username: "arvin.rosal",
      password: "password123",
      userType: "buyer",
      email: "arvin@example.com",
      fullName: "Arvin Jr. V. Rosal",
      mobileNumber: null,
      address: null,
      farmSize: null
    };
    this.users.set(1, user);

    // Create sample crops
    const sampleCrops: Crop[] = [
      {
        id: 1,
        name: "Tomatoes",
        price: "20.00",
        unit: "per kilo",
        quantity: 50,
        location: "Alamgusan, Cebu",
        description: "Fresh organic tomatoes",
        imageUrl: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        status: "available",
        farmerId: 2,
        createdAt: new Date(),
      },
      {
        id: 2,
        name: "Cabbage",
        price: "30.00",
        unit: "per kilo",
        quantity: 30,
        location: "Alamgusan, Cebu",
        description: "Fresh green cabbage",
        imageUrl: "https://images.unsplash.com/photo-1594282032945-2a3c4eaecfef?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        status: "sold",
        farmerId: 2,
        createdAt: new Date(),
      },
      {
        id: 3,
        name: "Carrots",
        price: "25.00",
        unit: "per kilo",
        quantity: 40,
        location: "Minglanilla, Cebu",
        description: "Organic farm-fresh carrots",
        imageUrl: "https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        status: "available",
        farmerId: 3,
        createdAt: new Date(),
      },
      {
        id: 4,
        name: "Bell Peppers",
        price: "45.00",
        unit: "per kilo",
        quantity: 25,
        location: "Talisay City, Cebu",
        description: "Mixed colored bell peppers",
        imageUrl: "https://images.unsplash.com/photo-1525607551316-4a8e16d1f9ba?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        status: "available",
        farmerId: 4,
        createdAt: new Date(),
      },
      {
        id: 5,
        name: "Lettuce",
        price: "35.00",
        unit: "per kilo",
        quantity: 20,
        location: "Lapu-Lapu City, Cebu",
        description: "Crispy fresh lettuce",
        imageUrl: "https://images.unsplash.com/photo-1622206151226-18ca2c9ab4a1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        status: "available",
        farmerId: 5,
        createdAt: new Date(),
      },
      {
        id: 6,
        name: "Pineapple",
        price: "50.00",
        unit: "per piece",
        quantity: 15,
        location: "Talisay City, Cebu",
        description: "Sweet tropical pineapples",
        imageUrl: "https://images.unsplash.com/photo-1589820296156-2454bb8a6ad1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        status: "available",
        farmerId: 4,
        createdAt: new Date(),
      }
    ];

    sampleCrops.forEach(crop => this.crops.set(crop.id, crop));

    // Create sample requests
    const sampleRequests: Request[] = [
      {
        id: 1,
        cropName: "Cabbage",
        quantity: 20,
        purpose: "Purchase",
        location: "Minglanilla, Cebu",
        additionalDetails: "",
        status: "pending",
        buyerId: 1,
        createdAt: new Date(),
      },
      {
        id: 2,
        cropName: "",
        quantity: 0,
        purpose: "Purchase",
        location: "",
        additionalDetails: "",
        status: "pending",
        buyerId: 1,
        createdAt: new Date(),
      },
      {
        id: 3,
        cropName: "pineapple",
        quantity: 5,
        purpose: "Purchase",
        location: "Talisay City",
        additionalDetails: "",
        status: "pending",
        buyerId: 1,
        createdAt: new Date(),
      }
    ];

    sampleRequests.forEach(request => this.requests.set(request.id, request));

    this.currentId = 7;
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      ...insertUser, 
      id,
      email: insertUser.email || null,
      fullName: insertUser.fullName || null,
      mobileNumber: insertUser.mobileNumber || null,
      address: insertUser.address || null,
      farmSize: insertUser.farmSize || null
    };
    this.users.set(id, user);
    return user;
  }

  // Crops
  async getAllCrops(): Promise<Crop[]> {
    return Array.from(this.crops.values());
  }

  async getCrop(id: number): Promise<Crop | undefined> {
    return this.crops.get(id);
  }

  async createCrop(insertCrop: InsertCrop): Promise<Crop> {
    const id = this.currentId++;
    const crop: Crop = { 
      ...insertCrop, 
      id,
      description: insertCrop.description || null,
      imageUrl: insertCrop.imageUrl || null,
      status: insertCrop.status || "available",
      createdAt: new Date() 
    };
    this.crops.set(id, crop);
    return crop;
  }

  async updateCrop(id: number, updates: Partial<Crop>): Promise<Crop | undefined> {
    const crop = this.crops.get(id);
    if (!crop) return undefined;
    
    const updatedCrop = { ...crop, ...updates };
    this.crops.set(id, updatedCrop);
    return updatedCrop;
  }

  // Requests
  async getAllRequests(): Promise<Request[]> {
    return Array.from(this.requests.values());
  }

  async getRequestsByBuyer(buyerId: number): Promise<Request[]> {
    return Array.from(this.requests.values()).filter(request => request.buyerId === buyerId);
  }

  async createRequest(requestData: InsertRequest & { buyerId: number }): Promise<Request> {
    const id = this.currentId++;
    const request: Request = { 
      ...requestData,
      id,
      status: "pending",
      additionalDetails: requestData.additionalDetails || null,
      createdAt: new Date() 
    };
    this.requests.set(id, request);
    return request;
  }

  // Transactions
  async getAllTransactions(): Promise<Transaction[]> {
    return Array.from(this.transactions.values());
  }

  async getTransactionsByUser(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(
      transaction => transaction.buyerId === userId || transaction.farmerId === userId
    );
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.currentId++;
    const transaction: Transaction = { 
      ...insertTransaction, 
      id,
      status: insertTransaction.status || "pending",
      totalAmount: insertTransaction.totalAmount || null,
      createdAt: new Date() 
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  // Conversations
  async getConversationsByUser(userId: number): Promise<Conversation[]> {
    return Array.from(this.conversations.values()).filter(
      conversation => conversation.user1Id === userId || conversation.user2Id === userId
    );
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const id = this.currentId++;
    const conversation: Conversation = { 
      ...insertConversation, 
      id, 
      lastMessageAt: new Date() 
    };
    this.conversations.set(id, conversation);
    return conversation;
  }

  // Messages
  async getMessagesByConversation(conversationId: number): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(
      message => message.conversationId === conversationId
    );
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentId++;
    const message: Message = { 
      ...insertMessage, 
      id, 
      createdAt: new Date() 
    };
    this.messages.set(id, message);
    return message;
  }
}

export const storage = new MemStorage();
