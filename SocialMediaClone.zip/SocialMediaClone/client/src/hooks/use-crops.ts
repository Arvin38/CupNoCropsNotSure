import { useQuery } from "@tanstack/react-query";
import type { Crop } from "@shared/schema";

export function useCrops() {
  return useQuery<Crop[]>({
    queryKey: ["/api/crops"],
  });
}
