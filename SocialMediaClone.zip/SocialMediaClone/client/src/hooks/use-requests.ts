import { useQuery } from "@tanstack/react-query";
import type { Request } from "@shared/schema";

export function useRequests() {
  return useQuery<Request[]>({
    queryKey: ["/api/requests"],
  });
}
