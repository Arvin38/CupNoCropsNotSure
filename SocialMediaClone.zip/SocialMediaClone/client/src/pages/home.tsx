import { useState } from "react";
import Header from "@/components/layout/header";
import Navigation from "@/components/layout/navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CropCard from "@/components/crops/crop-card";
import RequestItem from "@/components/requests/request-item";
import RequestCropModal from "@/components/modals/request-crop-modal";
import AddCropModal from "@/components/modals/add-crop-modal";
import { useCrops } from "@/hooks/use-crops";
import { useRequests } from "@/hooks/use-requests";
import { Store, ClipboardList, Handshake, MessageCircle, Clock, Search, Plus, ChartLine } from "lucide-react";

export default function Home() {
  const [activeTab, setActiveTab] = useState("home");
  const [isRequestModalOpen, setIsRequestModalOpen] = useState(false);
  const [isAddCropModalOpen, setIsAddCropModalOpen] = useState(false);
  const [selectedCropName, setSelectedCropName] = useState("");
  const [transactionFilter, setTransactionFilter] = useState("sales");
  const [historyFilter, setHistoryFilter] = useState("pending");

  const { data: crops = [], isLoading: cropsLoading } = useCrops();
  const { data: requests = [], isLoading: requestsLoading } = useRequests();

  const handleRequestCrop = (cropName: string = "") => {
    setSelectedCropName(cropName);
    setIsRequestModalOpen(true);
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <Navigation activeTab={activeTab} onTabChange={handleTabChange} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Home Tab */}
        {activeTab === "home" && (
          <div>
            {/* Hero Section */}
            <Card className="p-8 mb-8">
              <div 
                className="bg-cover bg-center rounded-lg p-12 text-white relative"
                style={{
                  backgroundImage: "linear-gradient(rgba(34, 197, 94, 0.8), rgba(34, 197, 94, 0.8)), url('https://images.unsplash.com/photo-1542838132-92c53300491e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=600')"
                }}
              >
                <div className="relative z-10 text-center">
                  <h1 className="text-4xl font-bold mb-4">Welcome to Sakanect</h1>
                  <p className="text-xl mb-6">Connecting farmers and buyers for fresh agricultural produce</p>
                  <Button 
                    onClick={() => handleTabChange("crops")}
                    className="bg-white text-primary hover:bg-gray-50"
                  >
                    Browse Available Crops
                  </Button>
                </div>
              </div>
            </Card>

            {/* Feature Cards */}
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <Card className="p-6">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <Store className="text-primary text-xl" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Browse Marketplace</h3>
                <p className="text-gray-600 mb-4">Discover fresh produce from local farmers with detailed information about quality and availability.</p>
                <Button 
                  variant="link" 
                  className="text-primary p-0 h-auto font-medium"
                  onClick={() => handleTabChange("crops")}
                >
                  Browse Now →
                </Button>
              </Card>

              <Card className="p-6">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <ClipboardList className="text-primary text-xl" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Request Crops</h3>
                <p className="text-gray-600 mb-4">Can't find what you need? Submit a request and let farmers know what you're looking for.</p>
                <Button 
                  variant="link" 
                  className="text-primary p-0 h-auto font-medium"
                  onClick={() => handleRequestCrop()}
                >
                  Make Request →
                </Button>
              </Card>

              <Card className="p-6">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <Handshake className="text-primary text-xl" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Secure Transactions</h3>
                <p className="text-gray-600 mb-4">Trade safely with our secure transaction system that protects both buyers and farmers.</p>
                <Button 
                  variant="link" 
                  className="text-primary p-0 h-auto font-medium"
                  onClick={() => handleTabChange("transactions")}
                >
                  Learn More →
                </Button>
              </Card>
            </div>

            {/* Statistics */}
            <div className="grid md:grid-cols-4 gap-6">
              <Card className="p-6 text-center">
                <div className="text-2xl font-bold text-primary mb-2">150+</div>
                <div className="text-sm text-gray-600">Active Farmers</div>
              </Card>
              <Card className="p-6 text-center">
                <div className="text-2xl font-bold text-primary mb-2">500+</div>
                <div className="text-sm text-gray-600">Available Crops</div>
              </Card>
              <Card className="p-6 text-center">
                <div className="text-2xl font-bold text-primary mb-2">1,200+</div>
                <div className="text-sm text-gray-600">Successful Trades</div>
              </Card>
              <Card className="p-6 text-center">
                <div className="text-2xl font-bold text-primary mb-2">95%</div>
                <div className="text-sm text-gray-600">Satisfaction Rate</div>
              </Card>
            </div>
          </div>
        )}

        {/* Crops Tab */}
        {activeTab === "crops" && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Available Crops</h2>
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <Input 
                    type="text" 
                    placeholder="Search crops..." 
                    className="pl-10 pr-4 py-2"
                  />
                  <Search className="absolute left-3 top-3 text-gray-400 h-4 w-4" />
                </div>
                <Select defaultValue="all">
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="vegetables">Vegetables</SelectItem>
                    <SelectItem value="fruits">Fruits</SelectItem>
                    <SelectItem value="grains">Grains</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={() => setIsAddCropModalOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Crop
                </Button>
              </div>
            </div>

            {cropsLoading ? (
              <div className="text-center py-8">Loading crops...</div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {crops.map((crop) => (
                  <CropCard 
                    key={crop.id} 
                    crop={crop} 
                    onRequest={() => handleRequestCrop(crop.name)} 
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Requests Tab */}
        {activeTab === "requests" && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">My Requests</h2>
              <Button onClick={() => handleRequestCrop()}>
                <Plus className="h-4 w-4 mr-2" />
                New Request
              </Button>
            </div>

            {requestsLoading ? (
              <div className="text-center py-8">Loading requests...</div>
            ) : (
              <div className="space-y-4">
                {requests.map((request) => (
                  <RequestItem key={request.id} request={request} />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Transactions Tab */}
        {activeTab === "transactions" && (
          <div>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Transactions</h2>
              <Tabs value={transactionFilter} onValueChange={setTransactionFilter}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="sales">Sales</TabsTrigger>
                  <TabsTrigger value="barters">Barters</TabsTrigger>
                  <TabsTrigger value="donations">Donations</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            <div className="text-center py-16">
              <ChartLine className="mx-auto h-16 w-16 text-gray-300 mb-4" />
              <p className="text-gray-500">No transactions yet</p>
              <p className="text-sm text-gray-400 mt-2">Your transaction history will appear here once you start trading</p>
            </div>
          </div>
        )}

        {/* Chat Tab */}
        {activeTab === "chat" && (
          <div className="grid md:grid-cols-3 gap-6 h-96">
            {/* Conversations Sidebar */}
            <Card>
              <div className="p-4 border-b border-gray-200">
                <h3 className="font-semibold text-gray-900">Conversations</h3>
              </div>
              <div className="p-4 text-center">
                <MessageCircle className="mx-auto h-16 w-16 text-gray-300 mb-4" />
                <p className="text-gray-500">No conversations yet</p>
              </div>
            </Card>

            {/* Chat Area */}
            <Card className="md:col-span-2">
              <div className="p-4 border-b border-gray-200">
                <h3 className="font-semibold text-gray-900">Select a conversation</h3>
              </div>
              <div className="p-8 text-center h-full flex items-center justify-center">
                <div>
                  <MessageCircle className="mx-auto h-16 w-16 text-gray-300 mb-4" />
                  <p className="text-gray-500">Select a conversation to start chatting</p>
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* History Tab */}
        {activeTab === "history" && (
          <div>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Transaction History</h2>
              <Tabs value={historyFilter} onValueChange={setHistoryFilter}>
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="pending">Pending</TabsTrigger>
                  <TabsTrigger value="completed">Completed</TabsTrigger>
                  <TabsTrigger value="declined">Declined</TabsTrigger>
                  <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            <div className="text-center py-16">
              <Clock className="mx-auto h-16 w-16 text-gray-300 mb-4" />
              <p className="text-gray-500">No transaction history yet</p>
              <p className="text-sm text-gray-400 mt-2">Your transaction history will appear here</p>
            </div>
          </div>
        )}
      </main>

      <RequestCropModal 
        isOpen={isRequestModalOpen}
        onClose={() => setIsRequestModalOpen(false)}
        defaultCropName={selectedCropName}
      />

      <AddCropModal 
        isOpen={isAddCropModalOpen}
        onClose={() => setIsAddCropModalOpen(false)}
      />
    </div>
  );
}
