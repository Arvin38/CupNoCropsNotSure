import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema } from "@shared/schema";
import { z } from "zod";
import { MapPin, Truck, Handshake, Users } from "lucide-react";

const signupSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(1, "Confirm password is required"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

const loginSchema = z.object({
  email: z.string().email("Please enter a valid email"),
  password: z.string().min(1, "Password is required"),
});

type SignupFormData = z.infer<typeof signupSchema>;
type LoginFormData = z.infer<typeof loginSchema>;

export default function Landing() {
  const [signupModalOpen, setSignupModalOpen] = useState(false);
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [signupType, setSignupType] = useState<"farmer" | "buyer">("buyer");
  const [showPassword, setShowPassword] = useState(false);
  const { toast } = useToast();

  const signupForm = useForm<SignupFormData>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      userType: signupType,
    },
  });

  const loginForm = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
  });

  const signupMutation = useMutation({
    mutationFn: async (data: Omit<SignupFormData, "confirmPassword">) => {
      const response = await fetch("/api/auth/signup", {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
        },
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Signup failed");
      }
      
      return response.json();
    },
    onSuccess: (response) => {
      toast({
        title: "Account created successfully!",
        description: "You can now log in with your credentials.",
      });
      localStorage.setItem("user", JSON.stringify(response.user));
      setSignupModalOpen(false);
      signupForm.reset();
      window.location.reload();
    },
    onError: (error: Error) => {
      toast({
        title: "Signup failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  const loginMutation = useMutation({
    mutationFn: async (data: LoginFormData) => {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
        },
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Login failed");
      }
      
      return response.json();
    },
    onSuccess: (response) => {
      toast({
        title: "Login successful!",
        description: "Welcome back to Sakanect.",
      });
      localStorage.setItem("user", JSON.stringify(response.user));
      setLoginModalOpen(false);
      loginForm.reset();
      window.location.reload();
    },
    onError: (error: Error) => {
      toast({
        title: "Login failed",
        description: error.message || "Please check your credentials and try again.",
        variant: "destructive",
      });
    },
  });

  const handleSignupClick = (type: "farmer" | "buyer") => {
    setSignupType(type);
    signupForm.setValue("userType", type);
    setSignupModalOpen(true);
  };

  const onSignupSubmit = (data: SignupFormData) => {
    const { confirmPassword, ...submitData } = data;
    signupMutation.mutate(submitData);
  };

  const onLoginSubmit = (data: LoginFormData) => {
    loginMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-6">
            <MapPin className="text-white text-3xl" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Sakanect</h1>
          <p className="text-lg text-gray-600">
            Connect farmers and buyers across the Philippines
          </p>
        </div>

        {/* Feature Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="p-0 overflow-hidden">
            <div 
              className="h-40 bg-cover bg-center relative"
              style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1542838132-92c53300491e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200')"
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-black/30">
                <div className="absolute top-4 left-4">
                  <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center">
                    <Truck className="text-white text-xl" />
                  </div>
                </div>
                <div className="absolute bottom-4 left-4 text-white">
                  <h3 className="text-lg font-semibold mb-1">Fresh Produce</h3>
                  <p className="text-sm text-gray-200">
                    Direct from local farmers to your table
                  </p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-0 overflow-hidden">
            <div 
              className="h-40 bg-cover bg-center relative"
              style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1500937386664-56d1dfef3854?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200')"
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-black/30">
                <div className="absolute top-4 left-4">
                  <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center">
                    <Handshake className="text-white text-xl" />
                  </div>
                </div>
                <div className="absolute bottom-4 left-4 text-white">
                  <h3 className="text-lg font-semibold mb-1">Fair Trade</h3>
                  <p className="text-sm text-gray-200">
                    Connect directly and trade fairly
                  </p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-0 overflow-hidden">
            <div 
              className="h-40 bg-cover bg-center relative"
              style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200')"
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-black/30">
                <div className="absolute top-4 left-4">
                  <div className="w-12 h-12 bg-pink-500 rounded-lg flex items-center justify-center">
                    <Users className="text-white text-xl" />
                  </div>
                </div>
                <div className="absolute bottom-4 left-4 text-white">
                  <h3 className="text-lg font-semibold mb-1">Local Network</h3>
                  <p className="text-sm text-gray-200">
                    Find suppliers and buyers in your area
                  </p>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="text-center space-y-4">
          <div className="flex justify-center space-x-4">
            <Button 
              onClick={() => handleSignupClick("farmer")}
              className="bg-primary hover:bg-primary/90 text-white px-8 py-3"
            >
              Sign up as Farmer
            </Button>
            <Button 
              onClick={() => handleSignupClick("buyer")}
              variant="outline"
              className="border-primary text-primary hover:bg-primary hover:text-white px-8 py-3"
            >
              Sign up as Buyer
            </Button>
          </div>
          
          <Button 
            variant="ghost"
            className="text-gray-600 hover:text-gray-800"
          >
            Continue as Guest
          </Button>

          <div className="mt-8">
            <p className="text-gray-600 mb-2">Already have an account?</p>
            <Button 
              variant="link" 
              onClick={() => setLoginModalOpen(true)}
              className="text-primary hover:text-primary/80"
            >
              Sign In
            </Button>
          </div>
        </div>
      </div>

      {/* Signup Modal */}
      <Dialog open={signupModalOpen} onOpenChange={setSignupModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-xl font-semibold">
              Sign Up as {signupType === "farmer" ? "Farmer" : "Buyer"}
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={signupForm.handleSubmit(onSignupSubmit)} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                {...signupForm.register("username")}
                placeholder="Enter your username"
              />
              {signupForm.formState.errors.username && (
                <p className="text-sm text-red-600">{signupForm.formState.errors.username.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                {...signupForm.register("email")}
                placeholder="Enter your email"
              />
              {signupForm.formState.errors.email && (
                <p className="text-sm text-red-600">{signupForm.formState.errors.email.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input
                id="fullName"
                {...signupForm.register("fullName")}
                placeholder="Enter your full name"
              />
              {signupForm.formState.errors.fullName && (
                <p className="text-sm text-red-600">{signupForm.formState.errors.fullName.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                {...signupForm.register("password")}
                placeholder="Enter your password"
              />
              {signupForm.formState.errors.password && (
                <p className="text-sm text-red-600">{signupForm.formState.errors.password.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <Input
                id="confirmPassword"
                type={showPassword ? "text" : "password"}
                {...signupForm.register("confirmPassword")}
                placeholder="Confirm your password"
              />
              {signupForm.formState.errors.confirmPassword && (
                <p className="text-sm text-red-600">{signupForm.formState.errors.confirmPassword.message}</p>
              )}
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="showPasswordSignup"
                checked={showPassword}
                onChange={(e) => setShowPassword(e.target.checked)}
                className="rounded"
              />
              <Label htmlFor="showPasswordSignup" className="text-sm">
                Show password
              </Label>
            </div>

            <div className="flex space-x-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setSignupModalOpen(false)}
                className="flex-1"
                disabled={signupMutation.isPending}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-green-600 hover:bg-green-700"
                disabled={signupMutation.isPending}
              >
                {signupMutation.isPending ? "Creating Account..." : "Sign Up"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Login Modal */}
      <Dialog open={loginModalOpen} onOpenChange={setLoginModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-xl font-semibold">
              Welcome Back
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="loginEmail">Email</Label>
              <Input
                id="loginEmail"
                type="email"
                {...loginForm.register("email")}
                placeholder="Enter your email"
              />
              {loginForm.formState.errors.email && (
                <p className="text-sm text-red-600">{loginForm.formState.errors.email.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="loginPassword">Password</Label>
              <Input
                id="loginPassword"
                type={showPassword ? "text" : "password"}
                {...loginForm.register("password")}
                placeholder="Enter your password"
              />
              {loginForm.formState.errors.password && (
                <p className="text-sm text-red-600">{loginForm.formState.errors.password.message}</p>
              )}
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="showPasswordLogin"
                checked={showPassword}
                onChange={(e) => setShowPassword(e.target.checked)}
                className="rounded"
              />
              <Label htmlFor="showPasswordLogin" className="text-sm">
                Show password
              </Label>
            </div>

            <div className="flex space-x-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setLoginModalOpen(false)}
                className="flex-1"
                disabled={loginMutation.isPending}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-green-600 hover:bg-green-700"
                disabled={loginMutation.isPending}
              >
                {loginMutation.isPending ? "Signing In..." : "Sign In"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}