import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Eye } from "lucide-react";
import type { Crop } from "@shared/schema";

interface CropCardProps {
  crop: Crop;
  onRequest: () => void;
}

export default function CropCard({ crop, onRequest }: CropCardProps) {
  const isAvailable = crop.status === "available";

  return (
    <Card className="overflow-hidden">
      <img 
        src={crop.imageUrl || "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200"} 
        alt={crop.name}
        className="w-full h-48 object-cover"
      />
      <CardContent className="p-4">
        <h3 className="text-lg font-semibold mb-2">{crop.name}</h3>
        <p className="text-xl font-bold text-primary mb-2">₱{crop.price} {crop.unit}</p>
        <p className="text-sm text-gray-600 mb-1">Quantity: {crop.quantity} {crop.unit.includes("kilo") ? "kilos" : "pieces"} available</p>
        <p className="text-sm text-gray-600 mb-3">Location: {crop.location}</p>
        <p className="text-sm text-gray-700 mb-3">{crop.description}</p>
        
        <div className="flex items-center justify-between mb-3">
          <div className="flex space-x-2">
            <Badge 
              variant={isAvailable ? "default" : "secondary"}
              className={isAvailable ? "bg-green-100 text-green-800" : "bg-orange-100 text-orange-800"}
            >
              {isAvailable ? "Available" : "Sold"}
            </Badge>
            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
              Fresh
            </Badge>
          </div>
          <Button variant="ghost" size="sm">
            <Eye className="h-4 w-4" />
          </Button>
        </div>
        
        <Button 
          onClick={onRequest}
          disabled={!isAvailable}
          className="w-full"
          variant={isAvailable ? "default" : "secondary"}
        >
          {isAvailable ? "Request" : "Sold Out"}
        </Button>
      </CardContent>
    </Card>
  );
}
