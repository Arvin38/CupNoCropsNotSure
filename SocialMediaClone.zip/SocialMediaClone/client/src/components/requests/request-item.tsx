import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User } from "lucide-react";
import type { Request } from "@shared/schema";

interface RequestItemProps {
  request: Request;
}

export default function RequestItem({ request }: RequestItemProps) {
  const formatDate = (date: Date | string) => {
    const d = new Date(date);
    return d.toLocaleDateString();
  };

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
              <User className="h-6 w-6 text-gray-500" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">
                Request for {request.cropName || ""}
              </h3>
              <p className="text-sm text-gray-600">Quantity: {request.quantity} kilos</p>
              <p className="text-sm text-gray-600">Location: {request.location}</p>
            </div>
          </div>
          <div className="text-right">
            <Badge 
              variant="secondary"
              className="bg-yellow-100 text-yellow-800"
            >
              {request.status}
            </Badge>
            <p className="text-sm text-gray-500 mt-1">
              {formatDate(request.createdAt || new Date())}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
