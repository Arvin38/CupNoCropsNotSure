import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { X } from "lucide-react";

interface AddCropModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AddCropModal({ isOpen, onClose }: AddCropModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    price: "",
    unit: "per kilo",
    quantity: "",
    location: "",
    description: "",
    imageUrl: ""
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const addCropMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const cropData = {
        name: data.name,
        price: data.price,
        unit: data.unit,
        quantity: parseInt(data.quantity),
        location: data.location,
        description: data.description,
        imageUrl: data.imageUrl || null,
        status: "available",
        farmerId: 2 // Default farmer ID for now
      };

      const response = await apiRequest("POST", "/api/crops", cropData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Crop added successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/crops"] });
      handleClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add crop. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    setFormData({
      name: "",
      price: "",
      unit: "per kilo",
      quantity: "",
      location: "",
      description: "",
      imageUrl: ""
    });
    onClose();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.price || !formData.quantity || !formData.location) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    addCropMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex justify-between items-center">
            <DialogTitle>Add New Crop</DialogTitle>
            <Button variant="ghost" size="sm" onClick={handleClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name" className="text-sm font-medium text-gray-700">
              Crop Name *
            </Label>
            <Input
              id="name"
              type="text"
              placeholder="e.g. Tomatoes"
              value={formData.name}
              onChange={(e) => handleInputChange("name", e.target.value)}
              className="mt-1"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="price" className="text-sm font-medium text-gray-700">
                Price (₱) *
              </Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                placeholder="0.00"
                value={formData.price}
                onChange={(e) => handleInputChange("price", e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="unit" className="text-sm font-medium text-gray-700">
                Unit *
              </Label>
              <Select value={formData.unit} onValueChange={(value) => handleInputChange("unit", value)}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="per kilo">per kilo</SelectItem>
                  <SelectItem value="per piece">per piece</SelectItem>
                  <SelectItem value="per bundle">per bundle</SelectItem>
                  <SelectItem value="per sack">per sack</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="quantity" className="text-sm font-medium text-gray-700">
              Available Quantity *
            </Label>
            <Input
              id="quantity"
              type="number"
              placeholder="0"
              value={formData.quantity}
              onChange={(e) => handleInputChange("quantity", e.target.value)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="location" className="text-sm font-medium text-gray-700">
              Location *
            </Label>
            <Input
              id="location"
              type="text"
              placeholder="Your farm location"
              value={formData.location}
              onChange={(e) => handleInputChange("location", e.target.value)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="description" className="text-sm font-medium text-gray-700">
              Description
            </Label>
            <Textarea
              id="description"
              rows={3}
              placeholder="Describe your crop quality, growing conditions..."
              value={formData.description}
              onChange={(e) => handleInputChange("description", e.target.value)}
              className="mt-1 resize-none"
            />
          </div>

          <div>
            <Label htmlFor="imageUrl" className="text-sm font-medium text-gray-700">
              Image URL (optional)
            </Label>
            <Input
              id="imageUrl"
              type="url"
              placeholder="https://example.com/image.jpg"
              value={formData.imageUrl}
              onChange={(e) => handleInputChange("imageUrl", e.target.value)}
              className="mt-1"
            />
          </div>

          <div className="flex space-x-3 pt-4">
            <Button type="button" variant="outline" onClick={handleClose} className="flex-1">
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="flex-1"
              disabled={addCropMutation.isPending}
            >
              {addCropMutation.isPending ? "Adding..." : "Add Crop"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}