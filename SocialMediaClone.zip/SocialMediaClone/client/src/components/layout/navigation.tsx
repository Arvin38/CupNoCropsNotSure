import { Button } from "@/components/ui/button";
import { Home, Wheat, FileText, ArrowLeftRight, MessageCircle, History } from "lucide-react";

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function Navigation({ activeTab, onTabChange }: NavigationProps) {
  const navItems = [
    { id: "home", label: "Home", icon: Home },
    { id: "crops", label: "Crops", icon: Wheat },
    { id: "requests", label: "Requests", icon: FileText },
    { id: "transactions", label: "Transactions", icon: ArrowLeftRight },
    { id: "chat", label: "Chat", icon: MessageCircle },
    { id: "history", label: "History", icon: History },
  ];

  return (
    <nav className="bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex space-x-8">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            
            return (
              <Button
                key={item.id}
                variant="ghost"
                onClick={() => onTabChange(item.id)}
                className={`flex items-center px-1 py-4 text-sm font-medium border-b-2 rounded-none hover:border-gray-300 ${
                  isActive 
                    ? "text-primary border-primary" 
                    : "text-gray-500 border-transparent hover:text-gray-700"
                }`}
              >
                <Icon className="h-4 w-4 mr-2" />
                {item.label}
              </Button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
